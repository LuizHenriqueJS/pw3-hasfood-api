package br.com.LuizHenrique.Santana.hasfood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pw3HasfoodApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pw3HasfoodApiApplication.class, args);
	}

}
