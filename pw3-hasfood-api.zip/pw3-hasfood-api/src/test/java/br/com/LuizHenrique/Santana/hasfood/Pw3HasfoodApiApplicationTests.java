package br.com.LuizHenrique.Santana.hasfood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pw3HasfoodApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
